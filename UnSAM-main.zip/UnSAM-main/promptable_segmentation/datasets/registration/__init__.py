# Copyright (c) Micorsoft, Inc. and its affiliates.
from . import (
    register_coco_panoptic_annos_semseg_interactive_jointboxpoint,
    register_sam_mnode,
#    register_object365_od,
#     register_sam,
)

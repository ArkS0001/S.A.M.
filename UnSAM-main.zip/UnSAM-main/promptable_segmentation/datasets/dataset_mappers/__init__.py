# Copyright (c) Facebook, Inc. and its affiliates.
from .sam_baseline_dataset_mapper import build_transform_gen as sam_transform_gen
from .sam_baseline_dataset_mapper import SamBaselineDatasetMapper
from .inference_mapper_with_gt import CoCoInferenceDatasetMapper
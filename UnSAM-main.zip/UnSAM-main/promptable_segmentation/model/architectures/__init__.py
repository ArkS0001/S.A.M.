from .interactive_mask_dino import *
from semantic_sam.architectures.build import build_model
python demo_dico.py --input ../docs/demos/sa_234337.jpg \
    --output demo.jpg \
    --postprocess true \
    --opts MODEL.WEIGHTS cutler_cascade_final.pth \